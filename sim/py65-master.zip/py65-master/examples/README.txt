Some example code and usage:

$ py65mon -m 65Org16 -r examples/65Org16.boot.rom

Then paste in a hex file, such as examples/swapcase.hex

(Type in some mixed-case input and it will echo it back with the upper and lowercase swapped)
